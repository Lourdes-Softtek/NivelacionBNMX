insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE )
values(10001, 'in28minutes', 'Get AWS Certified', current_date,false );

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE )
values(10002, 'in28minutes', 'Learn DevOps', current_date,false );

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE )
values(10003, 'in28minutes', 'Learn Google Cloud', current_date,false );

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE )
values(10004, 'in28minutes', 'Learn Full Stack', current_date,false );